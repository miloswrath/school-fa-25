import React, { useState } from 'react';
import './App.css';

const emojis = [
  { emoji: "😀", name: "grinning face" },
  { emoji: "🎉", name: "party popper" },
  { emoji: "💃", name: "woman dancing" }
];

function App() {
  const [clickedName, setClickedName] = useState('');
  const [mode, setMode] = useState('default'); // default mode only on refresh

  const handleEmojiClick = (e, name) => {
    e.stopPropagation();           // prevent container click
    setClickedName(name);
    setMode('picture');            // switch to picture mode
  };

  const handleBackgroundClick = () => {
    if (mode !== 'background') {
      setMode('background');       // purple background mode
    }
  };

  const currentClass =
    mode === 'picture'
      ? 'picture-active'
      : mode === 'background'
        ? 'background-active'
        : 'default-mode';

  const statusLabel =
    mode === 'picture'
      ? 'Picture active'
      : mode === 'background'
        ? 'Background active'
        : 'Default';

  const isPictureActive = mode === 'picture';

  return (
    <div className={`container ${currentClass}`} onClick={handleBackgroundClick}>
      <h1 id="greeting">Hello, World</h1>
      <p>I am writing JSX</p>

      <ul className="emoji-list">
        {emojis.map(({ emoji, name }) => (
          <li key={name}>
            <button
              className="emoji-button"
              onClick={(e) => handleEmojiClick(e, name)}
              aria-pressed={isPictureActive}
            >
              <span role="img" aria-label={name}>{emoji}</span>
            </button>
          </li>
        ))}
      </ul>

      {clickedName && <div className="message">You clicked: {clickedName}</div>}
      <div className="status">
        Mode: {statusLabel}
      </div>
    </div>
  );
}

export default App;
