export default function Main() {
  return (
    <div className="main">
      <h2>TITLE HEADING</h2>
      <h5>Title description</h5>
      <div className="fakeimg tall">Image</div>
      <p>Some text..</p>
      <p>
        Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur
        adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
        magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.
      </p>
    </div>
  );
}
