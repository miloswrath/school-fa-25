function formatToday() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${mm}/${dd}/${yyyy}`;
}

export default function Footer() {
  return (
    <div className="footer">
      <h4>{formatToday()}</h4>
      <h2>Footer</h2>
    </div>
  );
}
