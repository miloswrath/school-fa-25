import "./App.css";

function Main() {
  return (
    <div className="main">
      <h2>TITLE HEADING</h2>
      <h5>Title description</h5>
      <div className="fakeimg">Image</div>
      <p>Some text..</p>
      <p>
        Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur
        adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
        magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.
      </p>
    </div>
  );
}

function Footer() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const yyyy = d.getFullYear();
  const today = `${mm}/${dd}/${yyyy}`;

  return (
    <div className="footer">
      <h4>{today}</h4>
      <h2>Footer</h2>
    </div>
  );
}

export default function App() {
  return (
    <>
      <div className="row">
        <Main />
      </div>
      <Footer />
    </>
  );
}

