import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";

// Create a root container if none exists (no index.html)
const rootEl =
  document.getElementById("root") ||
  (() => {
    const el = document.createElement("div");
    el.id = "root";
    document.body.appendChild(el);
    return el;
  })();

createRoot(rootEl).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

